#!/usr/bin/env python3
"""
build_notes.py

Generates all JSONHTL convention documents for the notes system.
Outputs individual JSON files that can be PUT directly into gdata-server.

Usage:
    python3 build_notes.py                  # write files to current directory
    python3 build_notes.py --output /path   # write files to specified directory
    python3 build_notes.py --put http://localhost:8020  # PUT directly to server
"""

import json
import os
import sys
import argparse

# All documents keyed by their gdata key.
# Key "" is the root node.

documents = {}

# ============================================================
# Root node (key: "")
# ============================================================

documents[""] = {
    "title": "Notes System",
    "content": [
        {"heading": {"level": 1, "text": "Notes System"}},

        {"para": [
            "This is a JSONHTL document store. Each node is a JSON document "
            "stored under a plain string key. Documents are formatted using "
            "JSONHTL — a minimal JSON-based hypertext format."
        ]},

        {"para": [
            "To navigate, follow ",
            {"code": "link"},
            " elements. A link's ",
            {"code": "href"},
            " is either a key in this store or an external URL starting with ",
            {"code": "http://"},
            " or ",
            {"code": "https://"},
            "."
        ]},

        {"heading": {"level": 2, "text": "Conventions"}},

        {"para": [
            "This system uses conventions documented in ",
            {"link": {"href": "README", "text": "README"}},
            " (version 1). Read that document to understand the organisational "
            "and formatting conventions used here."
        ]},

        {"heading": {"level": 2, "text": "System Development"}},

        {"para": [
            "Planned improvements to this system are documented in ",
            {"link": {"href": "Future", "text": "Future"}},
            "."
        ]},
    ]
}

# ============================================================
# README (key: "README")
# ============================================================

documents["README"] = {
    "title": "README — Convention Guide",
    "version": 1,
    "content": [
        {"heading": {"level": 1, "text": "Convention Guide"}},

        {"para": [
            "This document describes the conventions used in this notes system. "
            "It supplements the base JSONHTL format specification. If you are "
            "an LLM or tool, check the version number above — if you already "
            "know version 1, you do not need to re-read this document."
        ]},

        {"heading": {"level": 2, "text": "Base Format"}},

        {"para": [
            "All documents use JSONHTL. The base format defines three block "
            "types (",
            {"code": "para"},
            ", ",
            {"code": "heading"},
            ", ",
            {"code": "codeblock"},
            ") and three inline types (plain strings, ",
            {"code": "link"},
            ", ",
            {"code": "code"},
            "). String values may also contain markdown inline formatting. "
            "See ",
            {"link": {"href": "README/format", "text": "Format Details"}},
            " for the full rules."
        ]},

        {"heading": {"level": 2, "text": "Links"}},

        {"para": [
            "Links connect documents in this store. A link may have an ",
            {"code": "href"},
            " that does not yet point to an existing node — this is permitted. "
            "See ",
            {"link": {"href": "README/links", "text": "Link Conventions"}},
            " for resolution rules."
        ]},

        {"heading": {"level": 2, "text": "Key Naming"}},

        {"para": [
            "Keys are plain strings. We use ",
            {"code": "/"},
            " as a logical separator to organise related documents, "
            "e.g. ",
            {"code": "README/format"},
            ". The server does not treat ",
            {"code": "/"},
            " specially — this is a convention only. "
            "See ",
            {"link": {"href": "README/keys", "text": "Key Conventions"}},
            " for details."
        ]},

        {"heading": {"level": 2, "text": "Document Size"}},

        {"para": [
            "Documents should be brief. Prefer many small, focused nodes "
            "over fewer large ones. This supports fine-grained recall — "
            "an LLM or tool can load only the specific information it needs "
            "without consuming unnecessary context window."
        ]},

        {"heading": {"level": 2, "text": "Metadata and Extensions"}},

        {"para": [
            "The base JSONHTL spec allows any top-level keys. Convention "
            "documents define what additional keys mean. See ",
            {"link": {"href": "README/metadata", "text": "Metadata Conventions"}},
            " for keys like ",
            {"code": "version"},
            ", ",
            {"code": "created"},
            ", and ",
            {"code": "tags"},
            "."
        ]},

        {"heading": {"level": 2, "text": "Future Extensions"}},

        {"para": [
            "Runnable documents (executable codeblocks) are planned. "
            "See ",
            {"link": {"href": "README/runnable", "text": "Runnable Document Conventions"}},
            " for the current placeholder."
        ]},
    ]
}

# ============================================================
# README/format (key: "README/format")
# ============================================================

documents["README/format"] = {
    "title": "Format Details",
    "content": [
        {"heading": {"level": 1, "text": "Format Details"}},

        {"para": [
            "This document covers formatting rules that extend the base "
            "JSONHTL specification."
        ]},

        {"heading": {"level": 2, "text": "Markdown in Strings"}},

        {"para": [
            "String values within JSONHTL may contain markdown inline "
            "formatting. For example, a paragraph string may include "
            "`backtick code`, **bold**, or *emphasis* using standard "
            "markdown syntax."
        ]},

        {"para": [
            "Where markdown and JSONHTL objects express the same thing, "
            "both are valid. For example, these are equivalent:"
        ]},

        {"codeblock": {"lang": "json", "body":
            '{"para": ["See ", {"code": "config.yaml"}, " for details."]}'
        }},

        {"codeblock": {"lang": "json", "body":
            '{"para": ["See `config.yaml` for details."]}'
        }},

        {"para": [
            "Similarly, a heading can be expressed as a JSONHTL block "
            "or as a markdown-formatted string within a ",
            {"code": "para"},
            " element, though the structured form is preferred for "
            "machine processing."
        ]},

        {"heading": {"level": 2, "text": "Normalisation"}},

        {"para": [
            "Systems may normalise all content to one form (structured "
            "JSONHTL objects or markdown strings). During the current "
            "phase, both coexist. A normaliser tool is planned — see ",
            {"link": {"href": "Future", "text": "Future"}},
            "."
        ]},

        {"heading": {"level": 2, "text": "Content Shorthand"}},

        {"para": [
            {"code": "content"},
            " may be a plain string instead of a list. The string ",
            {"code": "\"Just some text.\""},
            " is equivalent to ",
            {"code": "[{\"para\": [\"Just some text.\"]}]"},
            ". Parsers should normalise to list form internally."
        ]},

        {"para": [
            "Likewise, where any value is specified as a list, a bare "
            "scalar is shorthand for a single-element list."
        ]},
    ]
}

# ============================================================
# README/links (key: "README/links")
# ============================================================

documents["README/links"] = {
    "title": "Link Conventions",
    "content": [
        {"heading": {"level": 1, "text": "Link Conventions"}},

        {"heading": {"level": 2, "text": "Resolution"}},

        {"para": [
            "A link's ",
            {"code": "href"},
            " is resolved as follows:"
        ]},

        {"para": [
            "If it starts with ",
            {"code": "http://"},
            " or ",
            {"code": "https://"},
            ", it is an external web link."
        ]},

        {"para": [
            "Anything else is treated as a key in the local data store. "
            "The value is used directly as the key — no path manipulation "
            "or relative resolution is performed."
        ]},

        {"heading": {"level": 2, "text": "Missing Targets"}},

        {"para": [
            "A link may reference a key that does not yet exist. This is "
            "valid. It indicates a planned or placeholder document. "
            "Renderers should handle missing targets gracefully (e.g. "
            "display the link but indicate the target is absent)."
        ]},

        {"heading": {"level": 2, "text": "External Links"}},

        {"para": [
            "The behaviour when following an external link is not yet "
            "defined. The target could be a web page, another JSONHTL "
            "store, or something else entirely. This is reserved for "
            "future work."
        ]},
    ]
}

# ============================================================
# README/keys (key: "README/keys")
# ============================================================

documents["README/keys"] = {
    "title": "Key Conventions",
    "content": [
        {"heading": {"level": 1, "text": "Key Conventions"}},

        {"heading": {"level": 2, "text": "Separator"}},

        {"para": [
            "We use ",
            {"code": "/"},
            " as a logical separator in key names to group related "
            "documents. For example: ",
            {"code": "README"},
            ", ",
            {"code": "README/format"},
            ", ",
            {"code": "README/links"},
            "."
        ]},

        {"para": [
            "The server does not treat ",
            {"code": "/"},
            " specially. This is purely an organisational convention. "
            "Keys are opaque strings to the storage layer."
        ]},

        {"heading": {"level": 2, "text": "Root Node"}},

        {"para": [
            "The root node is stored under the empty-string key ",
            {"code": "\"\""},
            ". It serves as the bootstrap entry point for the system."
        ]},

        {"heading": {"level": 2, "text": "Naming Guidance"}},

        {"para": [
            "Keys should be concise and descriptive. Use lowercase "
            "where practical, except for established names like ",
            {"code": "README"},
            " and ",
            {"code": "Future"},
            ". Avoid spaces in keys — use ",
            {"code": "/"},
            " or ",
            {"code": "-"},
            " to separate words."
        ]},

        {"heading": {"level": 2, "text": "Brevity"}},

        {"para": [
            "Prefer many small documents over fewer large ones. Each "
            "node should cover a single focused topic. This supports "
            "fine-grained retrieval — a consumer loads only what it "
            "needs, keeping context window usage minimal."
        ]},
    ]
}

# ============================================================
# README/metadata (key: "README/metadata")
# ============================================================

documents["README/metadata"] = {
    "title": "Metadata Conventions",
    "content": [
        {"heading": {"level": 1, "text": "Metadata Conventions"}},

        {"para": [
            "JSONHTL allows any top-level keys alongside ",
            {"code": "content"},
            ". This document defines the conventional metadata keys "
            "used in this system."
        ]},

        {"heading": {"level": 2, "text": "Standard Keys"}},

        {"para": [
            {"code": "title"},
            " (string) — human-readable title for the document."
        ]},

        {"para": [
            {"code": "version"},
            " (integer) — version number for the document. An LLM or tool "
            "that remembers the version it last read can skip re-reading "
            "unchanged documents."
        ]},

        {"para": [
            {"code": "created"},
            " (string, ISO date) — date the document was created."
        ]},

        {"para": [
            {"code": "updated"},
            " (string, ISO date) — date the document was last modified."
        ]},

        {"para": [
            {"code": "tags"},
            " (list of strings) — freeform tags for categorisation "
            "and search."
        ]},

        {"heading": {"level": 2, "text": "Unknown Keys"}},

        {"para": [
            "Per the JSONHTL spec, consumers should ignore any top-level "
            "keys they do not recognise. New metadata keys may be "
            "introduced by adding them to this document."
        ]},
    ]
}

# ============================================================
# README/runnable (key: "README/runnable")
# ============================================================

documents["README/runnable"] = {
    "title": "Runnable Document Conventions",
    "content": [
        {"heading": {"level": 1, "text": "Runnable Document Conventions"}},

        {"para": [
            "This is a placeholder. Runnable documents will allow "
            "codeblocks to be executed, similar in concept to Jupyter "
            "notebooks but designed primarily for LLM consumption "
            "rather than human interaction."
        ]},

        {"para": [
            "Planned extensions to ",
            {"code": "codeblock"},
            " include additional keys such as ",
            {"code": "name"},
            " (to reference blocks), ",
            {"code": "exec"},
            " (to mark a block as executable), and output capture. "
            "These will be defined here when the feature is designed."
        ]},
    ]
}

# ============================================================
# Future (key: "Future")
# ============================================================

documents["Future"] = {
    "title": "Future — Planned Developments",
    "content": [
        {"heading": {"level": 1, "text": "Planned Developments"}},

        {"para": [
            "This document tracks planned improvements to the notes "
            "system. Items here are intentions, not commitments — "
            "details will be worked out when each feature is addressed."
        ]},

        {"heading": {"level": 2, "text": "Linter"}},

        {"para": [
            "A tool to validate that nodes conform to the JSONHTL spec "
            "and the conventions documented in ",
            {"link": {"href": "README", "text": "README"}},
            ". Should check structural validity (correct block/inline "
            "types, required keys present) and convention compliance "
            "(key naming, metadata keys, document brevity). May "
            "eventually be stored as a runnable codeblock node itself."
        ]},

        {"heading": {"level": 2, "text": "Renderer"}},

        {"para": [
            "A JSONHTL-to-HTML converter. Takes a node's JSON and "
            "produces a standalone HTML page. Links between nodes "
            "become navigable hyperlinks. Should handle both the "
            "structured JSONHTL objects and markdown-in-strings."
        ]},

        {"heading": {"level": 2, "text": "Normaliser"}},

        {"para": [
            "A tool to convert between the two equivalent inline "
            "formatting approaches: JSONHTL objects (",
            {"code": "{\"code\": \"x\"}"},
            ") and markdown strings (",
            {"code": "`x`"},
            "). Allows the system to settle on one canonical form "
            "after a period of mixed usage."
        ]},

        {"heading": {"level": 2, "text": "Browser"}},

        {"para": [
            "A human-readable viewer for navigating the node store. "
            "Could be a terminal application, a local web app, or "
            "both. Displays rendered JSONHTL with clickable links "
            "between nodes."
        ]},

        {"heading": {"level": 2, "text": "External Link Resolution"}},

        {"para": [
            "Define what happens when following an external link "
            "(one starting with ",
            {"code": "http://"},
            " or ",
            {"code": "https://"},
            "). The target might be a web page, another JSONHTL "
            "store, or an API endpoint. Needs a resolution protocol."
        ]},

        {"heading": {"level": 2, "text": "Runnable Documents"}},

        {"para": [
            "Executable codeblocks within nodes, similar in concept "
            "to Jupyter notebooks but oriented towards LLM execution. "
            "See ",
            {"link": {"href": "README/runnable", "text": "Runnable Document Conventions"}},
            " for the current placeholder."
        ]},

        {"heading": {"level": 2, "text": "Search and Indexing"}},

        {"para": [
            "A way to find content across nodes beyond knowing keys "
            "directly. Could be full-text search over node content, "
            "tag-based filtering, or a generated index node that "
            "lists all keys with summaries."
        ]},
    ]
}


# ============================================================
# Output
# ============================================================

def write_files(documents, output_dir):
    """Write each document as a JSON file."""
    os.makedirs(output_dir, exist_ok=True)

    for key, doc in documents.items():
        # Convert key to safe filename
        if key == "":
            filename = "_root.json"
        else:
            filename = key.replace("/", "_") + ".json"

        filepath = os.path.join(output_dir, filename)
        with open(filepath, "w") as f:
            json.dump(doc, f, indent=2, ensure_ascii=False)
            f.write("\n")
        print(f"  {filepath}  (key: \"{key}\")")


def put_to_server(documents, base_url):
    """PUT each document to a gdata-server instance."""
    import urllib.request

    base_url = base_url.rstrip("/")

    for key, doc in documents.items():
        url = f"{base_url}/{key}"
        data = json.dumps(doc, ensure_ascii=False).encode("utf-8")

        req = urllib.request.Request(
            url, data=data, method="PUT",
            headers={"Content-Type": "application/json"}
        )

        try:
            with urllib.request.urlopen(req) as resp:
                status = resp.status
                print(f"  PUT /{key} -> {status}")
        except Exception as e:
            print(f"  PUT /{key} -> FAILED: {e}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Generate JSONHTL convention documents"
    )
    parser.add_argument(
        "--output", "-o", default=".",
        help="Output directory for JSON files (default: current directory)"
    )
    parser.add_argument(
        "--put", metavar="URL",
        help="PUT documents directly to a gdata-server URL"
    )
    args = parser.parse_args()

    print(f"Generating {len(documents)} documents...\n")

    if args.put:
        print(f"Uploading to {args.put}:")
        put_to_server(documents, args.put)
    else:
        print(f"Writing to {args.output}:")
        write_files(documents, args.output)

    print(f"\nDone. {len(documents)} documents generated.")
    print("\nDocument map:")
    for key in documents:
        title = documents[key].get("title", "(no title)")
        display_key = '""' if key == "" else key
        print(f"  {display_key:30s} {title}")
